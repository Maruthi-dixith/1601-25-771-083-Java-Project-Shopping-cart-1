import java.util.ArrayList;
import java.util.Scanner;

public class ShoppingCartApp {
    private static final ArrayList<Product> catalog = new ArrayList<>();

    public static void main(String[] args) {
        loadProducts();
        ShoppingCart cart = new ShoppingCart();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            printMenu();
            choice = readInt(sc, "Enter your choice: ");

            switch (choice) {
                case 1:
                    displayProducts();
                    break;
                case 2:
                    addToCart(sc, cart);
                    break;
                case 3:
                    cart.displayCart();
                    break;
                case 4:
                    updateCartItem(sc, cart);
                    break;
                case 5:
                    removeCartItem(sc, cart);
                    break;
                case 6:
                    applyCoupon(sc, cart);
                    break;
                case 7:
                    checkout(sc, cart);
                    break;
                case 8:
                    System.out.println("Thank you for shopping with us!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select a number from 1 to 8.");
            }
        } while (choice != 8);

        sc.close();
    }

    // Product catalog (ID, name, price in Rs., stock)
    private static void loadProducts() {
        catalog.add(new Product(1, "Laptop", 55000.00, 5));
        catalog.add(new Product(2, "Smartphone", 20000.00, 10));
        catalog.add(new Product(3, "Headphones", 1500.00, 20));
        catalog.add(new Product(4, "Keyboard", 800.00, 15));
        catalog.add(new Product(5, "Mouse", 500.00, 25));
        catalog.add(new Product(6, "Backpack", 1200.00, 12));
        catalog.add(new Product(7, "Water Bottle", 250.00, 40));
        catalog.add(new Product(8, "Notebook (Pack of 5)", 300.00, 50));
    }

    private static void printMenu() {
        System.out.println("\n========================================");
        System.out.println("          SHOPPING CART SYSTEM");
        System.out.println("========================================");
        System.out.println("1. View Products");
        System.out.println("2. Add Item to Cart");
        System.out.println("3. View Cart");
        System.out.println("4. Update Item Quantity");
        System.out.println("5. Remove Item from Cart");
        System.out.println("6. Apply Coupon");
        System.out.println("7. Checkout");
        System.out.println("8. Exit");
    }

    // Reads an integer, asking again until the input is a valid number
    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private static Product findProduct(int id) {
        for (Product p : catalog) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    private static void displayProducts() {
        System.out.println("\n--------------- AVAILABLE PRODUCTS ---------------");
        System.out.printf("%-4s %-22s %10s %7s%n", "ID", "Product", "Price", "Stock");
        System.out.println("--------------------------------------------------");
        for (Product p : catalog) {
            System.out.printf("%-4d %-22s %10.2f %7d%n",
                    p.getId(), p.getName(), p.getPrice(), p.getStock());
        }
        System.out.println("--------------------------------------------------");
    }

    private static void addToCart(Scanner sc, ShoppingCart cart) {
        displayProducts();
        int id = readInt(sc, "Enter product ID: ");
        Product product = findProduct(id);
        if (product == null) {
            System.out.println("Invalid product ID.");
            return;
        }
        int quantity = readInt(sc, "Enter quantity: ");
        System.out.println(cart.addItem(product, quantity));
    }

    private static void updateCartItem(Scanner sc, ShoppingCart cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        cart.displayCart();
        int id = readInt(sc, "Enter product ID to update: ");
        int quantity = readInt(sc, "Enter new quantity: ");
        System.out.println(cart.updateQuantity(id, quantity));
    }

    private static void removeCartItem(Scanner sc, ShoppingCart cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        cart.displayCart();
        int id = readInt(sc, "Enter product ID to remove: ");
        System.out.println(cart.removeItem(id));
    }

    private static void applyCoupon(Scanner sc, ShoppingCart cart) {
        if (cart.isEmpty()) {
            System.out.println("Add items to your cart before applying a coupon.");
            return;
        }
        System.out.print("Enter coupon code (SAVE10 / SAVE20): ");
        System.out.println(cart.applyCoupon(sc.nextLine()));
    }

    private static void checkout(Scanner sc, ShoppingCart cart) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty. Add items before checkout.");
            return;
        }
        System.out.print("Enter customer name: ");
        String name = sc.nextLine().trim();
        if (name.isEmpty()) {
            name = "Customer";
        }
        cart.checkout(name);
    }
}

// Represents a product available in the store
class Product {
    private final int id;
    private final String name;
    private final double price;
    private int stock;

    public Product(int id, String name, double price, int stock) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }

    public void reduceStock(int quantity) {
        stock -= quantity;
    }
}

// Represents one line in the cart: a product and its quantity
class CartItem {
    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getSubtotal() {
        return product.getPrice() * quantity;
    }
}

// Holds the cart items and performs all cart and billing operations
class ShoppingCart {
    private static final double GST_RATE = 0.18;

    private final ArrayList<CartItem> items = new ArrayList<>();
    private String couponCode = "";
    private double discountRate = 0.0;

    public boolean isEmpty() {
        return items.isEmpty();
    }

    private CartItem findItem(int productId) {
        for (CartItem item : items) {
            if (item.getProduct().getId() == productId) {
                return item;
            }
        }
        return null;
    }

    // Adds a product to the cart after checking quantity and stock
    public String addItem(Product product, int quantity) {
        if (quantity <= 0) {
            return "Quantity must be at least 1.";
        }
        CartItem existing = findItem(product.getId());
        int alreadyInCart = (existing == null) ? 0 : existing.getQuantity();
        if (alreadyInCart + quantity > product.getStock()) {
            return "Not enough stock. Only " + product.getStock() + " unit(s) of "
                    + product.getName() + " available.";
        }
        if (existing == null) {
            items.add(new CartItem(product, quantity));
        } else {
            existing.setQuantity(alreadyInCart + quantity);
        }
        return quantity + " x " + product.getName() + " added to cart.";
    }

    // Changes the quantity of an item already in the cart
    public String updateQuantity(int productId, int newQuantity) {
        CartItem item = findItem(productId);
        if (item == null) {
            return "That product is not in your cart.";
        }
        if (newQuantity <= 0) {
            return "Quantity must be at least 1. Use Remove Item to delete it.";
        }
        if (newQuantity > item.getProduct().getStock()) {
            return "Not enough stock. Only " + item.getProduct().getStock() + " unit(s) available.";
        }
        item.setQuantity(newQuantity);
        return "Quantity updated for " + item.getProduct().getName() + ".";
    }

    public String removeItem(int productId) {
        CartItem item = findItem(productId);
        if (item == null) {
            return "That product is not in your cart.";
        }
        items.remove(item);
        return item.getProduct().getName() + " removed from cart.";
    }

    // Applies a coupon code (case-insensitive)
    public String applyCoupon(String code) {
        String c = code.trim().toUpperCase();
        if (c.equals("SAVE10")) {
            couponCode = c;
            discountRate = 0.10;
            return "Coupon SAVE10 applied: 10% discount.";
        } else if (c.equals("SAVE20")) {
            couponCode = c;
            discountRate = 0.20;
            return "Coupon SAVE20 applied: 20% discount.";
        }
        return "Invalid coupon code.";
    }

    public double getSubtotal() {
        double total = 0;
        for (CartItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    public double getDiscount() {
        return getSubtotal() * discountRate;
    }

    public double getGst() {
        return (getSubtotal() - getDiscount()) * GST_RATE;
    }

    public double getTotal() {
        return getSubtotal() - getDiscount() + getGst();
    }

    private void printItems() {
        System.out.println("----------------------------------------------------------------");
        System.out.printf("%-4s %-22s %10s %5s %14s%n", "ID", "Product", "Price", "Qty", "Subtotal");
        System.out.println("----------------------------------------------------------------");
        for (CartItem item : items) {
            Product p = item.getProduct();
            System.out.printf("%-4d %-22s %10.2f %5d %14.2f%n",
                    p.getId(), p.getName(), p.getPrice(), item.getQuantity(), item.getSubtotal());
        }
        System.out.println("----------------------------------------------------------------");
    }

    private void printTotals() {
        System.out.printf("%-43s %14.2f%n", "Subtotal:", getSubtotal());
        if (discountRate > 0) {
            System.out.printf("%-43s %14.2f%n",
                    "Discount (" + couponCode + ", " + (int) (discountRate * 100) + "%):", -getDiscount());
        }
        System.out.printf("%-43s %14.2f%n", "GST (18%):", getGst());
        System.out.printf("%-43s %14.2f%n", "Total Payable (Rs.):", getTotal());
    }

    public void displayCart() {
        if (items.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        System.out.println("\n                       YOUR CART");
        printItems();
        printTotals();
    }

    // Prints the final bill, reduces stock and empties the cart
    public void checkout(String customerName) {
        System.out.println("\n================================================================");
        System.out.println("                        FINAL BILL");
        System.out.println("================================================================");
        System.out.println("Customer: " + customerName);
        printItems();
        printTotals();
        System.out.println("================================================================");
        System.out.println("Thank you for your purchase, " + customerName + "!");

        for (CartItem item : items) {
            item.getProduct().reduceStock(item.getQuantity());
        }
        items.clear();
        couponCode = "";
        discountRate = 0.0;
    }
}
